<?php

class Services_Twilio_Rest_IPMessaging_Member extends Services_Twilio_IPMessagingInstanceResource {

}
